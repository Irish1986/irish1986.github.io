---
layout: post
title: "Tour Okuma"
author: "Harvey, Simon"
categories: journal
tags: [documentation,sample]
image: lathe.jpg
---

Voici un vieux tour Okuma, P&WC devrait en acheter un.

## Documentation

```
CUTCOM\MAKE,PART,NOW
```

## Sample code

<table border="0">
 <tr>
    <td><b style="font-size:30px">APT</b></td>
    <td><b style="font-size:30px">NC Code</b></td>
 </tr>
 <tr>
    <td>LOADTL\1, LENGTH, 100</td>
    <td>T1H100M06</td>
 </tr>
</table>

## Questions?

Non merci

## Denis achete des hotdogs
